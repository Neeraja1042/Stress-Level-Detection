from flask import Flask, request, jsonify, render_template
import tensorflow as tf
import numpy as np
import pickle
import traceback
import os

app = Flask(__name__)

# Load the trained model
model = tf.keras.models.load_model('stress_detection_rnn_model.h5')

# Load the scaler
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

# Define stress levels
stress_levels = ['Low', 'Moderate', 'High', 'Very High']

@app.route('/')
def home():
    return render_template('stress3.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get JSON data from request
        data = request.json
        print("Received data:", data)  # Debugging line

        # Ensure we have exactly 7 features
        if len(data) != 7:
            return jsonify({'error': 'Expected 7 features for prediction'}), 400

        # Convert input data to numpy array
        input_data = np.array([data])

        # Scale the input data
        input_data_scaled = scaler.transform(input_data)

        # Reshape data for LSTM (samples, timesteps, features)
        input_data_rnn = input_data_scaled.reshape((input_data_scaled.shape[0], input_data_scaled.shape[1], 1))

        # Make the prediction
        prediction = model.predict(input_data_rnn)
        predicted_class = np.argmax(prediction, axis=1)[0]
        predicted_stress = stress_levels[predicted_class]

        # Return the result as JSON
        return jsonify({
            'predicted_class': int(predicted_class),
            'predicted_stress': predicted_stress
        })

    except Exception as e:
        print("Error making prediction:", traceback.format_exc())
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
